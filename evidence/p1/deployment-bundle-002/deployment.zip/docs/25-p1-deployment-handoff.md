# P1 deployment handoff

Updated October 8, 2026. This is the operational handoff for the existing stopped Pod. It does not authorize an automatic restart or claim that P1 is accepted. Evidence history remains in [document 24](24-p1-implementation-status.md).

## Current decision

Keep the Pod stopped while artifact publication/restoration and the deployment bundle are completed. The clean Linux/Python-3.12 serving installation, dependency checks and nine CPU imports have passed. GPU loading, memory behavior, generated tool calls and a real repair remain unverified. Training qualification is a separate P5 requirement; a successful P1 inference run cannot guarantee a training streak will be error-free.

The authenticated [Pod read](../evidence/p1/pod-read-20261008/configuration.json) returned `EXITED` for `ywpfgef6yvnr9m`, image `runpod/pytorch:1.0.2-cu1281-torch280-ubuntu2404`, one NVIDIA A100-SXM4-80GB, disk 80, and empty mounts. The API cost field was 1.59; recheck the live rate before the next paid run. An empty mounts field does not prove that a particular directory survives stopping or termination. Verify actual storage backing before putting working artifacts there. Do not use the API GPU object's `memory: 117` field as VRAM evidence; the named GPU is the 80GB model and device memory must be checked with the driver.

## Artifacts to stage

| Artifact | Exact size / identity source | Use |
|---|---|---|
| Complete Gemma checkpoint | 23,297,590,856 bytes; [model manifest](../evidence/p1/model-intake-001/model-manifest.json) | Base-model inference; eight files, outside Git |
| Serving wheels | 5,331,545,654 bytes; [250-wheel manifest](../evidence/p1/runtime-wheels-002/manifest.json) | Offline Python-3.12/Linux x86_64 installation |
| R2 bootstrap | 16,666,629 bytes; [bootstrap manifest](../evidence/p1/bootstrap-001/manifest.json) | Eight small client wheels plus hash-pinned requirements; bootstrap verification is tracked separately |
| Official starter | [manifest](../evidence/p1/starter-bundle-001/manifest.json) | Harness/compiler assets; placeholder adapters are not trained candidates |
| Reserved development pilot | [manifest](../evidence/p1/pilot-bundle-001/manifest.json) | Agent-visible task projection, snapshot, graph and embeddings |
| Task sandbox dependencies | [manifest](../evidence/p1/wheels-001/manifest.json) | Python-3.13 task executor; separate from Python-3.12 serving environment |
| Deployment code/configuration | Curated bundle still to be assembled and hashed | Restoration, integrity checks, launch planning and inference probe |

Trust manifests from the local deployment handoff, not an unverified object fetched alongside arbitrary data. R2 credentials are supplied separately and never included in the code bundle, model directory, agent sandbox or submission. A successful publish receipt requires remote hash readback; a restore receipt separately proves reconstruction into a fresh destination. Check both before declaring recovery readiness.

## Execution order after the user restarts the Pod

1. Confirm the intended Pod identity, SSH access, Linux x86_64, Python 3.12 availability, NVIDIA driver/device visibility and actual free storage. The original PyTorch 2.8 environment must not be reused as the qualified serving environment. The candidate requires Torch 2.10.0 and the complete recorded dependency set.
2. Establish the verified persistent working directory and copy the small bootstrap/code bundle. Check its local manifest before execution. If the required interpreter is absent, provision and verify it before installing packages; do not silently use another Python version.
3. Create a dedicated bootstrap virtual environment. Install its requirements with `--no-index --find-links=<bootstrap-wheels> --require-hashes`, run dependency checks, then use the existing R2 restoration command with explicit byte limits and new destination directories.
4. Restore the model, serving wheels and required pilot assets. Reverify manifests. Reserve space for the extracted virtual environment, logs and runtime caches; model and wheel download sizes alone are not the disk requirement. Stop preparation if measured free space is insufficient, without deleting unrelated files.
5. Create a separate serving virtual environment. Install [the serving lock](../requirements/serving-linux-py312.lock.txt) with `--no-index --find-links=<restored-serving-wheels> --require-hashes`; run `pip check` and `scripts/probe_serving_runtime.py` against the retained resolver report. Do not use the acquisition URL lock for offline deployment. The three local version exceptions remain explicit and prevent a claim of exact official environment parity.
6. Re-run model structural/numerical/layout checks as appropriate to the restored bytes, then regenerate the launch plan with `scripts/plan_serving.py` using the Pod's interpreter and model path. Bind the server to loopback and use SSH forwarding for access. Start the base model without placeholder adapters, using the recorded context and memory limits.
7. Record startup logs, actual peak device memory, readiness and elapsed time. Execute `scripts/probe_inference.py`; preserve every response and any failure. Require an actual generated tool call, real disk read and correctly linked continuation. A successful health endpoint alone is insufficient.
8. Execute a real development repair through the agent/harness and retain its patch and checks. The current Requests evaluator has a verified source-shadowing problem: tests import the installed distribution instead of the checkout. Resolve that issue or qualify a legitimate alternative development environment before making repair-success claims. A local source-path override must remain labeled diagnostic.
9. Upload and verify new evidence, confirm that required artifacts are recoverable, then return control of the stopped/running decision to the user under the agreed compute limits. No unattended training starts in P1.

## Gates still open before requesting restart

- Complete and independently restore the model and runtime R2 artifacts.
- Finish and verify the curated deployment bundle and bootstrap path.
- Confirm the persistence strategy and paid-run limits; the current stopped-Pod API cannot establish filesystem behavior or SSH readiness.
- Preserve the official evaluator source-selection finding and a defensible plan for real repair validation.

GPU correctness, CUDA kernels and actual model behavior require a bounded GPU run. CPU preparation reduces avoidable setup failures; it cannot honestly guarantee those results in advance.

## Transfer interruption and cleanup procedure

Run `scripts/audit_r2_multipart.py` with the exact model/runtime manifests and a secure environment-file path to record incomplete uploads. The auditor is read-only and bounded to `artifacts/v1/blobs/sha256/`. A matching hash identifies an artifact, not the owner or liveness of an upload. Age alone must never trigger an abort. The initial [audit](../evidence/p1/multipart-audit-001/receipt.json) found one incomplete runtime-wheel upload while publication was active; nothing was aborted.

If a transfer is interrupted, first determine whether the original process is actually terminal. Poll its existing handle; a timeout is not proof of termination. Do not launch a duplicate while it is alive. After a confirmed failure, retain its logs and rerun publication against the same immutable manifest with a new evidence directory. Completed objects are reused only after size/SHA-256 readback. An incomplete multipart object is not treated as a completed blob, and the current implementation restarts that object's upload rather than resuming old parts.

After transfers are terminal, repeat the audit. Investigate any remaining upload by its exact upload ID, object key, initiating process and initiation time. Abort only an upload attributable to a confirmed-dead attempt after ruling out another live writer. If attribution is uncertain, retain it for review. No bucket-wide lifecycle changes or blanket prefix aborts are authorized by this procedure. The read-only audit currently has no automatic-abort capability.

Two fault-injected tests prove bounded recovery properties: interruption after one complete remote object leaves no manifest commit and a fresh transport reuses that verified object; loss of the manifest acknowledgement after remote commit permits an idempotent retry without another manifest write. [Recovery test receipt](../evidence/p1/transport-recovery-001/receipt.json). These tests do not simulate a process killed inside a live multipart request. The original deployment bundle contains the earlier 70-test snapshot; regenerate the bundle to include subsequent auditor/test additions.
